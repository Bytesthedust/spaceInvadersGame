//class to represent aliens
//


#pragma once
#include <ncurses.h>
#include "drawable.hpp"
#include "invaders.hpp"


class Alien: public Drawable
{


	public:
       		Alien* next;
		int value;	

		Alien(int y, int x, chtype icon)
		{
			this->y = y;
			this->x = x;
			this->icon = icon;
			next = NULL;

			switch(icon)
			{
				case 'A':
					this->value = 40;
					break;
				case 'O':
					this->value = 30;
					break;
				case 'G':
					this->value = 20;
					break;
				case 'X':
					this->value = 10;
					break;
				default:
					this->value = 0;
					break;
			}

		}

		//get alien value
		int getValue(chtype ahead)
		{
			if(ahead == 'A')
				return 40;
			else if(ahead == 'O')
				return 30;
			else if(ahead == 'G')
				return 20;
			else if(ahead == 'X')
				return 10;

			return 0;
		}


		void alienRight()
		{

			this->x = x - 1;
		}

		void alienLeft()
		{
			this->x = x + 1;
		}

		void alienDown()
		{
			this->y = y + 1;
		}

		//push functions
		
			
		Alien* addToEmpty(Alien* last, int y, int x, chtype icon)
		{
			if(last != NULL)
				return last;
			
			Alien* newAlien = new Alien(y,x,icon);
			last = newAlien;
			last->next = last;

			return last;
		}

		Alien* addEnd(Alien* last, int y, int x, chtype icon)
		{
			if(last == NULL)
				return addToEmpty(last, y, x, icon);

			Alien* newAlien = new Alien(y,x,icon);
			newAlien->next = last->next;
			last->next = newAlien;

			last = newAlien;
			return last;
		}

		//delete function

		void deleteAlien(Alien** last, chtype key)
		{
			if(*last == NULL) return;

			if((*last)->icon == key && (*last)->next == *last)
			{
				delete(*last);
				*last = NULL;
				return;
			}

			Alien* temp = *last, *d;

			//if last is to be deleted
			if((*last)->icon == key)
			{
				while(temp->next != *last) temp = temp->next;

				temp->next = (*last)->next;
				delete(*last);
				*last = temp->next;
			}

			//traverse to alien to be deleted
			while(temp->next != *last && temp->next->icon != key) temp = temp->next;

			//if node is found
			if(temp->next->icon == key)
			{
				d = temp->next;
				temp->next = d->next;
				delete(d);
			}
		}


};

